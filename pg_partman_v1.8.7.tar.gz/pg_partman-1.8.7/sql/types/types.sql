CREATE TYPE check_parent_table AS (parent_table text, count bigint);
